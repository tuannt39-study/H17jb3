
## tour-online

### Đề tài 8:
- Xây dựng hệ thống website quản lý tour du lịch

### Thành viên:
- Ly, Hiến, Tuân, Thạo

### Framework:
- Hibernate, Spring MVC, Apache title
- Mysql, Tomcat